import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Headers } from "@angular/http";

@Component({
  selector: 'app-search-recipe',
  templateUrl: './search-recipe.component.html',
  styleUrls: ['./search-recipe.component.css']
})
export class SearchRecipeComponent implements OnInit {
  @ViewChild('recipe') recipes: ElementRef;
  @ViewChild('place') places: ElementRef;
  recipeValue: any;
  placeValue: any;
  venueList = [];
  recipeList = [];

  currentLat: any;
  currentLong: any;
  geolocationPosition: any;

  private recipe_url = `https://api.edamam.com/search?app_id=bcd3289c&app_key=173e0a544ed6bdcca394e88fe452e25f`;
  private location_url = `https://api.foursquare.com/v3/places/search?query=`

  constructor(private _http: HttpClient) {
  }

  ngOnInit() {

    window.navigator.geolocation.getCurrentPosition(
      position => {
        this.geolocationPosition = position;
        this.currentLat = position.coords.latitude;
        this.currentLong = position.coords.longitude;
      });
  }

  getVenues() {

    this.recipeValue = this.recipes.nativeElement.value;
    this.placeValue = this.places.nativeElement.value;

    // To get the recipe details by using get http
    if (this.recipeValue !== null) {
      this.recipeList = [];
      this._http.get(this.recipe_url + '&q=' + this.recipeValue ).subscribe(result => {
        const output_recipeData = result['hits'];
        console.log('Recipe Data', output_recipeData);
        output_recipeData.map(each => {
          this.recipeList.push({
            name: each.recipe.label,
            url: each.recipe.url,
            icon: each.recipe.image
          });
        });
        console.log(this.recipeList);
      });
    }

    // Code to get the Restaurant details by using get http
    if (this.placeValue != null && this.placeValue !== '' && this.recipeValue != null && this.recipeValue !== '') {
      this.venueList = [];
      const HTTP_headers = new HttpHeaders({
        Accept: "application/json",
        Authorization: "fsq3yqOCssKTh2VGw61HN6IiSO3JHd1RJrIuHBtEyFAULLs=",
      });
      this._http.get(this.location_url + this.recipeValue + '&near=' + this.placeValue + "&v=20220222",
        {headers: HTTP_headers}).subscribe((result: any) => {
        const output_locationData = result['results'];
        console.log('Location:', output_locationData);
        output_locationData.map(each => {
          this.venueList.push({
            name : each.name,
            location : {
              formattedAddress : [
                each.location.formatted_address,
                each.location.locality]
            }
          });
        });
        console.log(this.venueList);
      });
    }
  }
}
